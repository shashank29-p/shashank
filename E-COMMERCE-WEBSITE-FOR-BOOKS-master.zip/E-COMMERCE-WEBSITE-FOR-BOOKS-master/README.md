A full stack project which integrates the front end and backend to develop a e-commerce site to buy books.
 Using Java, Spring Boot, Hibernate, Thymeleaf, CSS, Html, Javascript.
