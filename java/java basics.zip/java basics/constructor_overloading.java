
class student {
    int id;
    String name;
    int age;

    student(int i, String n) {
        id = i;
        name = n;
    }

    student(int i, String n, int a) {
        id = i;
        name = n;
        age = a;
    }

    void display() {
        System.out.println(id + " " + name + " " + age);
    }
}

public class constructor_overloading {
    public static void main(String[] args) {
        student s = new student(1, "raaj");
        student s1 = new student(2, "raam", 22);
        s.display();
        s1.display();
    }
}
