import java.util.Scanner;

class nest{
    protected int id=123;
 public class inner{
     public int demo(){
         System.out.println("id "+id);
         return  id;
     }
 }
}
public class nested_class {
    public static void main(String[] args) {
        nest n=new nest();
        nest.inner in=n.new inner();
        in.demo();
    }
}
