
class method {
    public void draw() {
        System.out.println("hey draw");
    }

    public void drawable() {
        this.draw();
        System.out.println("hey drawable");
    }

}

public class thiskeywordmethod {
    public static void main(String[] args) {
        method m = new method();
        m.drawable();
    }
}
