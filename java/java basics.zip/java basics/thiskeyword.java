class calc {
    int num1;
    int num2;

    calc(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    void display() {
        System.out.println(num1 + " " + num2);
    }
}

public class thiskeyword {
    public static void main(String[] args) {
        calc calc = new calc(10, 20);
        calc.display();
    }
}
