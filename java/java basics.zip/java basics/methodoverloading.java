class overloading{
    public int sum(int a,int b){
        return a+b;
    }
    public int sum(int a,int b,int c){
        return a+b+c;
    }
}
public class methodoverloading {
    public static void main(String[] args) {
        overloading over=new overloading();
        System.out.println(over.sum(1,2));
        System.out.println(over.sum(3,2,1));

    }
}
