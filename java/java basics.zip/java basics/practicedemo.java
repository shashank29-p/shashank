import java.io.Serializable;

class bank implements Serializable {

     private int canara(int p, int t, int r) {
         int interest;
         interest=p*t*r/100;
         System.out.println(interest);
         return interest;
     }
     public int sbi() {
         int p=100,t=2,r=3;
         return canara(p,t,r);
     }
 }
 class cash extends bank{

 }
public class practicedemo {
    public static void main(String[] args) {
        cash c=new cash();
        bank b=new bank();
        if (b instanceof bank) {
            c.sbi();
        }
    }
}
