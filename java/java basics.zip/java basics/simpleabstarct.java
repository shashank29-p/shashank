abstract class human {
    public abstract void show();

    public void run() {
        System.out.println("hello");
    }
}

public class simpleabstarct extends human {
    @Override
    public void show() {
        super.run();
        System.out.println("hey");
    }

    public static void main(String[] args) {
        human obj = new simpleabstarct();
        obj.show();
    }


}
