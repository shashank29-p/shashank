import java.util.Scanner;

public class reverse {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("enter the word");
        String s= scan.nextLine();
        int length=s.length();
        StringBuilder s1=new StringBuilder();
        s1.append(s);
        if(s==null || s.length()==1){
            System.out.println("palindrome");
        }
        s1.reverse();
        if(s.contains(s1)) {
            System.out.println("palindrome");
        }
        else {
            System.out.println("not palindrome");
        }
    }
}
