import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class TestSubArray {
    public static void main(String[] args) {
        List<Number> list = new ArrayList<>();
        list.add(1);
        list.add(-2);
        list.add(3);
        System.out.println(list);
        for (int i = 0; i < list.size(); i++) {
            List<Number> lists = new ArrayList<>();
            lists.add(list.get(i));
            System.out.println(lists);
        }
        for (int i = 0; i < list.size(); i++) {
            for (int j = 0; j < list.size(); j++) {
                List<Integer> numberList = new LinkedList<>();
                if(i<j) {
                    numberList.add((Integer) list.get(j));
                    numberList.add((Integer) list.get(i));
                    System.out.println(numberList);
                }
            }
        }
    }
}
