public class Sample {
    public static void main(String[] args) {
        String a=new String();
        String b=new String();
        System.out.println(a+b);
    }
}
