class college {
    int rollno;
    String name;
    static String collegename = "RV";

    college(int rollno, String name) {
        this.rollno = rollno;
        this.name = name;
    }

    protected void show() {
        System.out.println(rollno + " " + name + " " + collegename);
    }

    static void change() {
        collegename = "sigma";
    }
}

public class static_basic {

    public static void main(String[] args) {
        college c = new college(1, "raj");
        c.show();
        college.change();
        college c1 = new college(2, "manohar");
        c1.show();
    }
}
