class overriding {
    public void sum() {
        System.out.println("this is sum");
    }
}

class overriding1 extends overriding {
    public void sum() {
        System.out.println("this is sum1");
    }
}

public class methodoverriding {
    public static void main(String[] args) {
        overriding overriding = new overriding();
        overriding.sum();
        overriding over = new overriding1();
        over.sum();

    }
}
