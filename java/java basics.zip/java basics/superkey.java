class humans{
    void nature(){
        System.out.println("this is a humans nature");
    }
    void run(String name){
        System.out.println(" name is :"+ name);
    }
}
class male extends humans{
    void behaviour(){
        super.nature();
        super.run("ranga");
        System.out.println("this is a male behaviour");
    }
}
public class superkey {
    public static void main(String[] args) {
        male m=new male();
        m.behaviour();
    }
}
