//non static nested class
class Outer {
    String fruit = "Apple";

    private class Inner {
        public void red() {
            System.out.println("This is inner class");
        }
    }

    public void display_flower() {
        Inner flowers = new Inner();
        flowers.red();
    }
}

public class innerclass2 {
    public static void main(String[] args) {
        Outer fruits = new Outer();
        fruits.display_flower();
    }
}
