import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class arraylist {
    public static void main(String[] args) {
        String a=new String();
        String b=new String();
        System.out.println(a+b);
    }
}
