//nested class using static
class A {
    String name = "raja";

    static class B {
        public void show() {
            A a = new A();
            System.out.println(a.name);
        }
    }
}

public class innerclass {
    public static void main(String[] args) {
        A.B ab = new A.B();
        ab.show();

    }
}
