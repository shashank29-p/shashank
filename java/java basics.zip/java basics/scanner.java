import java.util.Scanner;

public class scanner {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the value of a:");
            int a = scanner.nextInt();
            System.out.println("a value is:\n" + a);
            System.out.println("----------*--------------------*---------------");
        }
    }
}
