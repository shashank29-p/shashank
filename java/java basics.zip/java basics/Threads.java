public class Threads extends Thread {

    public void run() {
        System.out.println("new thread");
    }

    public static void main(String[] args) {
        Threads t=new Threads();
        t.start();
    }
}
